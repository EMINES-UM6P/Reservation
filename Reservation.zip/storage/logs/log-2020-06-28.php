<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-28 10:02:56 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Applications/MAMP/htdocs/Reservation/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2020-06-28 10:02:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Applications/MAMP/htdocs/Reservation/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2020-06-28 10:02:56 --> Unable to connect to the database
